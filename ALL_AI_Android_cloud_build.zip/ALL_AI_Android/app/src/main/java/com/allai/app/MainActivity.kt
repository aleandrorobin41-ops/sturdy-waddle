package com.allai.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF070914)
private val Panel = Color(0xFF11172A)
private val Cyan = Color(0xFF54E7FF)
private val Violet = Color(0xFF9B7CFF)
private val Muted = Color(0xFF9AA8C7)

data class ChatMessage(val text: String, val fromUser: Boolean)

enum class AiMode { MANUAL, AUTO }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AllAiApp() }
    }
}

@Composable
fun AllAiApp() {
    var mode by remember { mutableStateOf(AiMode.AUTO) }
    var selectedModel by remember { mutableStateOf("ALL AI Router") }
    var prompt by remember { mutableStateOf("") }
    var showSettings by remember { mutableStateOf(false) }
    val messages = remember {
        mutableStateListOf(
            ChatMessage("¡Hola! Soy ALL AI. Puedo ayudarte a escribir, aprender, programar y crear. ¿Qué hacemos hoy?", false)
        )
    }
    val models = listOf("ALL AI Router", "Gemini", "GPT", "Claude", "Groк", "DeepSeek", "Llama")

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Bg, surface = Panel, primary = Cyan,
            secondary = Violet, onBackground = Color.White,
            onSurface = Color.White
        )
    ) {
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(listOf(Color(0xFF101B38), Bg, Color(0xFF090B18)))
            )
        ) {
            Column(Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 18.dp)) {
                Row(
                    Modifier.fillMaxWidth().padding(top = 12.dp, bottom = 18.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        Modifier.size(42.dp).background(
                            Brush.linearGradient(listOf(Cyan, Violet)), RoundedCornerShape(14.dp)
                        ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.AutoAwesome, null, tint = Bg)
                    }
                    Spacer(Modifier.width(11.dp))
                    Column(Modifier.weight(1f)) {
                        Text("ALL AI", fontSize = 23.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
                        Text("TU CENTRO DE INTELIGENCIA", fontSize = 9.sp, color = Muted, letterSpacing = 1.5.sp)
                    }
                    IconButton(onClick = { showSettings = !showSettings }) {
                        Icon(Icons.Default.Tune, "Configuración", tint = Cyan)
                    }
                }

                if (showSettings) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Panel),
                        shape = RoundedCornerShape(18.dp),
                        modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
                    ) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("Configuración", fontWeight = FontWeight.Bold, color = Cyan)
                            Text("Versión inicial · Las conexiones reales a proveedores se añadirán mediante un backend seguro.", color = Muted, fontSize = 12.sp)
                        }
                    }
                }

                Text("¿QUÉ QUIERES HACER HOY?", color = Muted, fontSize = 11.sp, letterSpacing = 1.4.sp)
                Text("Una app. Muchas inteligencias.", fontSize = 21.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(14.dp))

                Row(
                    Modifier.fillMaxWidth().background(Panel, CircleShape).padding(4.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    ModeButton("✦ Automático", mode == AiMode.AUTO, Modifier.weight(1f)) { mode = AiMode.AUTO }
                    ModeButton("☷ Elegir IA", mode == AiMode.MANUAL, Modifier.weight(1f)) { mode = AiMode.MANUAL }
                }

                if (mode == AiMode.MANUAL) {
                    Spacer(Modifier.height(12.dp))
                    Text("SELECCIONA UN MODELO", color = Muted, fontSize = 10.sp, letterSpacing = 1.2.sp)
                    Spacer(Modifier.height(7.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        models.take(4).forEach { model ->
                            ModelChip(model, selectedModel == model) { selectedModel = model }
                        }
                    }
                    Spacer(Modifier.height(7.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        models.drop(4).forEach { model ->
                            ModelChip(model, selectedModel == model) { selectedModel = model }
                        }
                    }
                } else {
                    Spacer(Modifier.height(12.dp))
                    Surface(
                        color = Color(0x222BDAFF),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth().border(1.dp, Color(0x6654E7FF), RoundedCornerShape(12.dp))
                    ) {
                        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.AutoAwesome, null, tint = Cyan, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(9.dp))
                            Text("ALL AI elegirá el modelo adecuado según tu tarea.", color = Color(0xFFD6F8FF), fontSize = 12.sp)
                        }
                    }
                }

                Spacer(Modifier.height(16.dp))
                Text("CHAT", color = Muted, fontSize = 10.sp, letterSpacing = 1.5.sp)
                Spacer(Modifier.height(7.dp))

                LazyColumn(
                    modifier = Modifier.weight(1f).fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 12.dp)
                ) {
                    items(messages) { message ->
                        MessageBubble(message)
                    }
                }

                Row(
                    Modifier.fillMaxWidth().padding(bottom = 8.dp)
                        .background(Panel, RoundedCornerShape(18.dp))
                        .border(1.dp, Color(0x6654E7FF), RoundedCornerShape(18.dp))
                        .padding(horizontal = 13.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    BasicTextField(
                        value = prompt,
                        onValueChange = { prompt = it },
                        modifier = Modifier.weight(1f),
                        textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 14.sp),
                        cursorBrush = Brush.linearGradient(listOf(Cyan, Violet)),
                        decorationBox = { inner ->
                            Box {
                                if (prompt.isEmpty()) Text("Escribe tu mensaje...", color = Muted, fontSize = 14.sp)
                                inner()
                            }
                        }
                    )
                    Spacer(Modifier.width(8.dp))
                    IconButton(
                        onClick = {
                            val text = prompt.trim()
                            if (text.isNotEmpty()) {
                                messages.add(ChatMessage(text, true))
                                messages.add(ChatMessage(
                                    "La interfaz de ALL AI ya está funcionando. Para responder con un modelo real, el siguiente paso es conectar el backend seguro y un proveedor de IA. Modo: ${if (mode == AiMode.AUTO) "Automático" else selectedModel}.",
                                    false
                                ))
                                prompt = ""
                            }
                        },
                        modifier = Modifier.size(42.dp).background(
                            Brush.linearGradient(listOf(Cyan, Violet)), CircleShape
                        )
                    ) {
                        Icon(Icons.Default.Send, "Enviar", tint = Bg)
                    }
                }
                Text("ALL AI · PROTOTIPO 0.1 · CONEXIONES DE IA PENDIENTES", color = Muted, fontSize = 8.sp,
                    modifier = Modifier.align(Alignment.CenterHorizontally).padding(bottom = 7.dp))
            }
        }
    }
}

@Composable
private fun ModeButton(label: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Surface(
        onClick = onClick, modifier = modifier,
        color = if (selected) Color(0xFF263A60) else Color.Transparent,
        shape = CircleShape
    ) {
        Text(label, modifier = Modifier.padding(vertical = 11.dp), textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            color = if (selected) Cyan else Muted, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun ModelChip(label: String, selected: Boolean, onClick: () -> Unit) {
    Surface(onClick = onClick, color = if (selected) Color(0xFF29345A) else Panel,
        shape = RoundedCornerShape(10.dp), modifier = Modifier.border(
            1.dp, if (selected) Violet else Color(0x334A5A7A), RoundedCornerShape(10.dp)
        )) {
        Text(label, modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
            color = if (selected) Color.White else Muted, fontSize = 10.sp)
    }
}

@Composable
private fun MessageBubble(message: ChatMessage) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (message.fromUser) Arrangement.End else Arrangement.Start) {
        Surface(
            color = if (message.fromUser) Color(0xFF26345B) else Panel,
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.widthIn(max = 310.dp).border(
                1.dp, if (message.fromUser) Color(0x557F8CFF) else Color(0x3354E7FF),
                RoundedCornerShape(16.dp)
            )
        ) {
            Text(message.text, modifier = Modifier.padding(13.dp), color = Color(0xFFEAF2FF), fontSize = 13.sp)
        }
    }
}
