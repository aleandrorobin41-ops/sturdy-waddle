# ALL AI — Android starter (v0.1)

Proyecto Android nativo con Kotlin y Jetpack Compose.

## Qué incluye
- Interfaz holográfica oscura.
- Chat local de demostración.
- Selector visual de modelos y modos manual/automático.

## Importante
Este proyecto todavía NO integra APIs reales de proveedores de IA. Las respuestas actuales son demostrativas. Tampoco ofrece acceso ilimitado gratuito a modelos comerciales. La conexión real requiere un backend seguro y las credenciales autorizadas de cada proveedor.

## Generar el APK desde un celular (sin PC)
1. Crea o inicia sesión en una cuenta de GitHub desde el navegador del celular.
2. Crea un repositorio nuevo llamado `ALL-AI`.
3. Sube el contenido de este ZIP al repositorio, conservando las carpetas y archivos.
4. En GitHub, abre la pestaña **Actions** y habilita los workflows si te lo solicita.
5. Ejecuta **Build ALL AI APK** con **Run workflow** (o espera a que termine el build tras subir a `main`).
6. Abre la ejecución completada, baja hasta **Artifacts** y descarga `ALL-AI-debug-apk`.
7. Extrae el ZIP del artifact y encontrarás `app-debug.apk`. Ábrelo en Android para instalarlo. Android puede pedir permiso para instalar desde esa fuente.

## Requisitos de compilación
El workflow de GitHub Actions compila con Java 17, Gradle 8.9, Android SDK 35 y genera un APK debug.

## Seguridad y limitaciones
Nunca pongas claves API dentro de la app Android ni las subas al repositorio. Las claves deben guardarse en un backend. El APK debug es para pruebas, no es una versión de publicación firmada para Play Store.
